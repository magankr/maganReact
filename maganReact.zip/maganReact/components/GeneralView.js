import React from 'react';
import Chip from 'material-ui/Chip';
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import FileAttachment from'material-ui/svg-icons/file/attachment';
import Dialog from 'material-ui/Dialog';
import Divider from 'material-ui/Divider';
import TextField from 'material-ui/TextField';
const styles={

browseButton:{position:'inherit',
    left: '50%',
    top:' 15%',
    transform: 'translateX(-50%)',
    width:'30%',
    padding: 0},
	
imageInput:{position:'absolute',
width:'100%',
top:0,bottom:0,left:0,right:0,opacity:0,cursor:'pointer'}	
	

}

export default class GeneralView extends React.Component{
	constructor(props)
	{
		super(props);
		this.state={open:false,fileName:null,disabled:true};
	this.handleClose=this.handleClose.bind(this);
		this.handleOpen=this.handleOpen.bind(this);
		this.handleFile=this.handleFile.bind(this);
	}
	
	handleFile(e)
	{
	this.setState({fileName:e.target.value,disabled:false});
	}
	handleOpen(){
    this.setState({open: true});
  };

  handleClose() {
    this.setState({open: false});
  };

	render()
	{ 	
 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
      <FlatButton
        label="Upload It"
        primary={true}
		disabled={this.state.disabled}
        keyboardFocused={true}
        onTouchTap={this.handleClose}
      />,
    ];
	return(<div>
		<div className="container">
	 <div className="row">
	 <Paper className="specialOffer" zDepth={3} children={
	 <div className="col-lg12 col-xs-12 col-sm-12 col-md-12">
<RaisedButton label="Dialog" style={styles.browseButton} labelStyle={{color:'#fff'}} buttonStyle={{backgroundColor:'rgb(0, 188, 212)',height:50}} onTouchTap={this.handleOpen} />
        <Dialog
          title="Choose Only One Option"
		  actions={actions}
             modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
		  autoScrollBodyContent={true}
        >
<div className="otherOption">
  <span className="sectionTitle">
    Upload Your List
  </span>
</div>
     <FlatButton label="Choose file" primary={true} backgroundColor="#rgb(0, 188, 212)"  labelPosition="before" icon={<FileAttachment style={{color:'#fff'}}/>}>
  <input type="file" style={styles.imageInput} onChange={this.handleFile} />
</FlatButton>{this.state.fileName===null && <span className="fileNamePath">You haven't Upload your CheckList</span>
}
{this.state.fileName!="null" && <span className="fileNamePath">{this.state.fileName}</span>}
<div className="otherOption">

  <span className="sectionTitle">
    Make Your List
  </span>
</div>
 <TextField  className="searchbox"
      hintText="Hint Text" 
	  fullWidth={true}
      floatingLabelText="Baby Search Here....."
    />
        </Dialog>
	 
	 
	 </div>}/>
	 </div>	
		</div>
		
		</div>
		)
	}
} 