import React from 'react';
import {Tabs,Tab} from 'material-ui/Tabs';
import SwipeableViews from 'react-swipeable-views';
import GeneralView from './GeneralView';
import GeneralView1 from './GeneralView1';
export default class MultipleViews extends React.Component{
	constructor(props){
super(props);	
this.state={slideIndex:0}	
this.handleChange=this.handleChange.bind(this);
	}
	handleChange(value){
		  this.setState({
      slideIndex: value,
    });
		
		
	}
	render(){
		
		return(
		<div className="container">
		<div className="row" style={{marginTop:'125px'}}>
		<Tabs onChange={this.handleChange} tabItemContainerStyle={{backgroundColor:'rgb(0, 188, 212)'}} inkBarStyle={{backgroundColor:'#F5A623'}} value={this.slideIndex} >
		<Tab label="Tab A" style={{color:'#fff'}} value={0}/>
		<Tab label="Tab A" style={{color:'#fff'}} value={1}/>
		<Tab label="Tab A" style={{color:'#fff'}} value={2}/>
		</Tabs>
		<SwipeableViews 
index={this.state.slideIndex}
          onChangeIndex={this.handleChange}
		>
		
		<div>
         <GeneralView1/>
          </div>
          <div>
            <GeneralView/>
          </div>
          <div>
            slide n°3
          </div>
		
		</SwipeableViews>
		
		</div>
		</div>
		
		)
		
		
	}
	
}

