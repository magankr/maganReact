import React from 'react';
import {
  Step,
  Stepper,
  StepLabel,
  StepContent,
} from 'material-ui/Stepper';
import RaisedButton from 'material-ui/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';
import Divider from 'material-ui/Divider';
import CheckoutDetails from './CheckoutDetails';
import DatePicker from 'material-ui/DatePicker';


function disablePrevDate(startDate)
{   const futureDate=new Date((new Date()).getTime() + (30 * 86400000));//disabling Future date 
	const seconds=Date.parse(startDate);
	return(date=>{
		return Date.parse(date)<= seconds || Date.parse(date) >Date.parse(futureDate);
	})
} 

class Checkout extends React.Component {
constructor(props)
{super(props);
this. state = {
    finished: false,
    stepIndex: 0,selectedLoginType:false,
	selected:false,
	disableYearSelection:false,
	autoOk:true
  }
this.handleNext=this.handleNext.bind(this);
  
this.handlePrev=this.handlePrev.bind(this);

this.renderStepActions=this.renderStepActions.bind(this);
this.selectedDelivery=this.selectedDelivery.bind(this);
this.handleSelectedLogin=this.handleSelectedLogin.bind(this);
  }
 componentDidMount(){
	  $('html, body').animate({
        scrollTop: $(".shopcategoriesSection").offset().top-60
    }, 2000);
 }

 handleSelectedLogin(){
	 this.setState({selectedLoginType:true})
 }
  handleNext(){
    const {stepIndex} = this.state;
    this.setState({
      stepIndex: stepIndex + 1,
      finished: stepIndex >= 2,
    });
  };

  handlePrev(){
    const {stepIndex} = this.state;
    if (stepIndex > 0) {
      this.setState({stepIndex: stepIndex - 1,selected:false});
    }
  }
selectedDelivery(){
	this.setState({
      stepIndex: 1,selected:true
	});
}
  renderStepActions(step) {
    const {stepIndex} = this.state;

    return (
      <div style={{margin: '12px 0'}}>
        <RaisedButton
          label={stepIndex === 2 ? 'Finish' : 'Next'}
          disableTouchRipple={true}
          disableFocusRipple={true}
          primary={true}
          onTouchTap={this.handleNext}
          style={{marginRight: 12}}
        />
        {step > 0 && (
          <FlatButton
            label="Back"
            disabled={stepIndex === 0}
            disableTouchRipple={true}
            disableFocusRipple={true}
            onTouchTap={this.handlePrev}
          />
        )}
      </div>
    );
  }

  render() {
	  const startDate=new Date();
	  startDate.setDate(startDate.getDate()-1);
    const {finished, stepIndex} = this.state;

    return (
	 <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
		  <div className="selectedcategorytitle">Checkout</div>
		  </div>
		  <div className="row features-grid">
      <div style={{maxWidth:380, margin: 'auto'}}>
        <Stepper activeStep={stepIndex} orientation="vertical">
          <Step>
            <StepLabel>Select campaign settings</StepLabel>
            <StepContent>
              <div className="normal">
			  {!this.state.selectedLoginType && <div style={{marginTop:25}}>
			 
			  <RaisedButton
          label="Login in as Guest"          
          primary={true} style={{marginLeft:20}}
		     onTouchTap={this.handleNext}        
        />
		<Divider style={{marginTop:10,marginBottom:10}}/>
		<RaisedButton label="Login in as Primary" labelColor="#fff" style={{marginLeft:20}} backgroundColor="rgb(38, 166, 154)" onTouchTap={this.handleSelectedLogin}/>
  </div>
			  }
 
		{ this.state.selectedLoginType &&
               <div>
			   <TextField 
      hintText="Hint Text" 
      floatingLabelText="Baby Search Here....."
    />
	
    <TextField
      hintText="Password Field"
      floatingLabelText="Password"
      type="password"
    />
	{this.renderStepActions(0)}
	</div>
	 
	}

              </div>
             
            </StepContent>
          </Step>
          <Step>
            <StepLabel>Create an ad group</StepLabel>
            <StepContent>
              <CheckoutDetails selectedDelivery={this.selectedDelivery}/>
              {this.state.stepIndex==1 && this.state.selected===true ? this.renderStepActions(1):null}
            </StepContent>
          </Step>
          <Step>
            <StepLabel>Create an ad</StepLabel>
            <StepContent>
              <div>
                Try out different ad text to see what brings in the most customers
				<DatePicker 
				floatingLabelText="Select your Date"
				disableYearSelection={this.state.disableYearSelection} 
				shouldDisableDate={disablePrevDate(startDate)}
				autoOk={this.state.autoOk}
				/>
              </div>
              {this.renderStepActions(2)}
            </StepContent>
          </Step>
        </Stepper>
        {finished }
		</div>
      </div>
	  </div>
    );
  }
}

export default Checkout;