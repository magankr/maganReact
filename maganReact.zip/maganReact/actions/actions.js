import fetch from 'isomorphic-fetch';
 
export const SELECT_SUBMENU="SELECT_SUBMENU";
 
export function select_submenu(submenu){
	return {
		type:SELECT_SUBMENU,
		submenu
	}
	
} 

export const SELECTED_MENU_CLICK="SELECTED_MENU_CLICK";

export const selected_menu_click=(selectedmenuonClick)=>{
	console.log(selectedmenuonClick);
	return {
		type:SELECTED_MENU_CLICK,
		selectedmenuonClick
	}
	
}

export const REQUEST_SUBITEM="REQUEST_SUBITEM";
export const request_subItem=()=>{
	return {
	type:REQUEST_SUBITEM	
	}	
}

export const RECIEVE_FETCHSUBITEM="RECIEVE_FETCHSUBITEM";

export const fetchsubitem=(subcategoryItem)=>{
	return (dispatch)=>{
			dispatch(request_subItem());
		return fetch(`http://www.json-generator.com/api/json/get/ceVKPjaGeW`).then(response=>response.json()).
		then(json=>dispatch(recieveFetchSubitem(subcategoryItem,json)));
	}
	
}
export const recieveFetchSubitem=(subcategoryItem,json)=>{
	return {
		type:RECIEVE_FETCHSUBITEM,
		subcategoryItem,
		itemList:json
	}
}

export const REQUEST_MENU="REQUEST_MENU";
export const requestMenus=()=>{
	return {
	type:REQUEST_MENU	
	}	
}

export const RECIEVE_FETCHMENU="RECIEVE_FETCHMENU";
 
export const fetchmenus=()=>{

	return (dispatch)=>{
		dispatch(requestMenus());
		return fetch('http://54.254.254.57:8080/hsahu/api/menu-list/0').then(response=>response.json()).
		then(json=>dispatch(recieveFetchmenu(json)));
		
	}
	
}

export const recieveFetchmenu=(json)=>{
	

	return{
		type:RECIEVE_FETCHMENU,
	dataformenus:json.data.categories.map(category=>category.name),
	values:json.data.categories
	}
	
}

export const CHECK_PRODUCT_STATUS="CHECK_PRODUCT_STATUS";
export const fetch_product_status=()=>
{
	return(dispatch)=>{
		return fetch(`http://www.json-generator.com/api/json/get/bVFSWbCcHS`).then(response=> response.json())
		.then(json=>dispatch(recieve_product_status(json)))
	}
}
export const recieve_product_status=(addRequester)=>{
	return {type:CHECK_PRODUCT_STATUS,
    status:{"status": "Yes", "product_id": addRequester}	
}
}

export const SEARCHREQUESTSTART="SEARCHREQUESTSTART";

export const requestStartForSearch=()=>{
	return {
	type:SEARCHREQUESTSTART	
	}
}
export const searchrequest=(searchvalue)=>
{ console.log(searchvalue);
return (dispatch)=>{
console.log("Start of Searchrequest"+searchvalue)
dispatch(requestStartForSearch());
return fetch(`http://54.254.254.57:8080/hsahu/api/search/${searchvalue}`).then(response=>response.json()).
then(json=>dispatch(recieveSearchRequest(json)));

}
}

export const RECIEVE_SEARCH="RECIEVE_SEARCH";

export const recieveSearchRequest=(json)=>{
	console.log("Start of recieveSearchRequest");
	return {
	type:RECIEVE_SEARCH,
dataSourceAction:json.data
	}
}

export const SEARCH_LOCALLY="SEARCH_LOCALLY";
export const searchlocally=(searchlocallyValue)=>{

return{
	type:SEARCH_LOCALLY
}
}

