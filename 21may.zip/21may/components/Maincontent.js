import React from 'react';
import {Tabs,Tab} from 'material-ui/Tabs';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import CircularProgress from 'material-ui/CircularProgress';
import { Link } from 'react-router';
import FlatButton from 'material-ui/FlatButton';import {connect} from 'react-redux';
import {selected_menu_click,fetchsubitem,recieve_product_status} from '../actions/actions';
class Maincontent extends React.Component{

	constructor(props){
		super(props);
}


componentDidMount(){
console.log("Lets see",this.props.params.id);
let contentid=this.props.params.id=="undefined" ? "Grocery & Staples":this.props.params.id;
	console.log("Inside MainContent"+ contentid);
	this.props.dispatch(selected_menu_click(contentid));
}	
	
	
render(){
const {isListFetching,selectedmenuonclick,selectedcategoryName,Listitems,lastadded}=this.props;{/* missing layoutType*/}
console.log(selectedmenuonclick);
	return(
	 <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
		  <div className="selectedcategorytitle">{selectedcategoryName}</div>
		  </div>
    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
      	{/*<!-- Wrapper for slides -->*/}   
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
         	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
           	{/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
			{/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
	{/*<!-- End Carousel --> */} 




		  {isListFetching && <div className="row features-loader"><div className="alingCenter"><CircularProgress size={80} thickness={7} /></div></div>}
		
		{!isListFetching &&  <div className="row features-grid">
		  {typeof selectedmenuonclick !="undefined" && selectedmenuonclick.map((element,i)=>{
			  return (
		<div className="feature-tile" key={i}>
           <div className="feature-icon" >
       
        </div>
    <div>
	     <Link to={`/paytm/product/${element.name.name}`}> <h6 className="feature-title">{element.name.name}</h6></Link><p className="feature-description" >
		 {typeof element.name.products !="undefined" && element.name.products.map((secondText,i)=>{
			return ( <span key={i}>{secondText.name}</span>)
		})
		 }
	       </p>
	</div>
</div> 
			  )
		  })} {/* End of Layout 1 */}
		
	
</div>
}

{/* End of MainContent */}

</div> 

	)
}	
	
}

const mapStateToProps=(state,ownProps)=>{
	const {listofAddProduct,fetchmenuReducer,fetchsubitemReducer}=state;
const {selectedcategoryName,selectedmenuonclick}=fetchmenuReducer;
const {lastadded}=listofAddProduct;
console.log("jfdnklndfkglnfd",lastadded);
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
console.log("mapStateToProps in Maincontent "+selectedmenuonclick);
return {lastadded,selectedmenuonclick,isListFetching,Listitems,selectedcategoryName};

}


export default connect(mapStateToProps)(Maincontent);