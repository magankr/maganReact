import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';
import Snackbar from 'material-ui/Snackbar';
import CircularProgress from 'material-ui/CircularProgress';
import Dialog from 'material-ui/Dialog';
import MenuItem from 'material-ui/MenuItem';
import DropDownMenu from 'material-ui/DropDownMenu';
import FlatButton from 'material-ui/FlatButton';import {connect} from 'react-redux';
import {selected_menu_click,fetchsubitem,recieve_product_status} from '../actions/actions';
 var ClickedSubcategoryData=null;
 var subCategoryIndexing=null
class ProductList extends React.Component{

  constructor(props){
    super(props);
this.state={disabled:true,handleSnackbar:false,largeView:false,layoutType:1,dataForlargeView:null,updatePage:true};
this.handleLargeView=this.handleLargeView.bind(this);
this.handleClose=this.handleClose.bind(this);
this.handleAddProductRequest=this.handleAddProductRequest.bind(this);
this.handleChangeinDropDown=this.handleChangeinDropDown.bind(this);
}

handleChangeinDropDown(currentObject,parentId,event,key,value)
{
  console.log("lkjvlkfnvkfdnd",currentObject.childProducts[key],key,value);
      for(var i=0;i<ClickedSubcategoryData.products.length;i++)
    {       console.log(ClickedSubcategoryData.products[i].name,currentObject.childProducts[key]);
        if(ClickedSubcategoryData.products[i].id===parentId)
        {console.log(ClickedSubcategoryData.products[i].id, this.props.selectedmenuonclick[subCategoryIndexing].name);

         this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].id=currentObject.childProducts[key].id;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].name=currentObject.childProducts[key].name;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productNameTag=currentObject.childProducts[key].productNameTag;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].tag=currentObject.childProducts[key].tag;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].status=currentObject.childProducts[key].status;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].description=currentObject.childProducts[key].description;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productPrice=currentObject.childProducts[key].productPrice;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountedPrice=currentObject.childProducts[key].discountedPrice;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountPerCent=currentObject.childProducts[key].discountPerCent;
               this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].discountedAomunt=currentObject.childProducts[key].discountedAomunt;
             this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productBrand=currentObject.childProducts[key].productBrand;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].deliveryCharge=currentObject.childProducts[key].deliveryCharge;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].serchCount=currentObject.childProducts[key].serchCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].orderCount=currentObject.childProducts[key].orderCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].hitCount=currentObject.childProducts[key].hitCount;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].stock=currentObject.childProducts[key].stock;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].imgUrl=currentObject.childProducts[key].imgUrl;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productQuantity=currentObject.childProducts[key].productQuantity;
              this.props.selectedmenuonclick[subCategoryIndexing].name.products[i].productUnit=currentObject.childProducts[key].productUnit;
                  console.log("Cdcdcd",this.props.selectedmenuonclick,this.props.lastadded,value);
                 const checkalreadyIncart=this.props.lastadded.findIndex((entry,index)=> {
                          console.log("Fdfhdjfbdkjbf",entry.id,value);
                            if (entry.id ===value)
                              return true
                            })
                  console.log(checkalreadyIncart);
                        if(checkalreadyIncart!=-1)
                        {console.log("ndjbfjd");
                      this.setState({disabled:value});
                         }




          }
                break;
   }
    this.setState({updatePage:true});
  }

handleLargeView(dataValue)
{ console.log(dataValue);
  this.setState({handleSnackbar:false,largeView:true,dataForlargeView:dataValue});
}
handleClose(){
    this.setState({handleSnackbar:false,largeView: false});
  }

handleAddProductRequest(addRequest,event)
{console.log("handleAddProductRequest",addRequest,this.props.lastadded);
    document.getElementById(addRequest).disabled;
const alreadyIncart=this.props.lastadded.some(entry=> {
  console.log(entry.id,addRequest);
    if (entry.id ===addRequest)
      return true
    });
if(!alreadyIncart)
{
   this.props.dispatch(recieve_product_status(addRequest));
    document.getElementById(addRequest).disabled;
    document.getElementById(addRequest).style.backgroundColor = 'rgba(247,246,207,0.4)';
 this.setState({disabled:addRequest});
}
  
   
  }

componentWillReceiveProps(nextProps) {
console.log(nextProps.lastadded);
    if (nextProps.lastadded != this.props.lastadded) {
  this.setState({handleSnackbar:true});
    }
  }
componentDidMount(){
   
  console.log(this.props.params.id);  //  this.props.dispatch(fetchsubitem(this.props.params.id));
} 
  
  
render(){
const {lastadded,selectedmenuonclick,isListFetching,Listitems,selectedcategoryName}=this.props;{/* missing layoutType*/}
console.log("fnllnvsvsnvms vnvkn",lastadded);
var item=[];
for(var i=0;i<selectedmenuonclick.length;i++)
{console.log(selectedmenuonclick[i].name.name,this.props.params.id);

if(selectedmenuonclick[i].name.name===this.props.params.id)
{ console.log("dffffdfdfff",selectedmenuonclick[i].name.name);
   ClickedSubcategoryData=selectedmenuonclick[i].name;
   subCategoryIndexing=i;
 for(var element=0;element<selectedmenuonclick[i].name.products.length;element++)
{
  item.push(<div className="col-lg-3 col-md-3 col-xs-5 col-sm-5 productcol" key={element} id={selectedmenuonclick[i].name.products[element].id}>{/*<!--- Start of productcol-->*/}

         <div className="productDisplaySection">
<img src="C:/Users/753554/Downloads/checkonly.png" className="productimage"  onClick={this.handleLargeView.bind(null,selectedmenuonclick[i].name.products[element])}  />
    
         </div>
         <div  className=" col-lg-8 col-md-8 col-xs-8 productNameHeader">{selectedmenuonclick[i].name.products[element].name},{selectedmenuonclick[i].name.products[element].id}</div>
      
        <div  className=" col-lg-4 col-md-4 col-xs-4" style={{float:'right',padding:0,top:0}} >
          <DropDownMenu value={selectedmenuonclick[i].name.products[element].id}  underlineStyle={{margin:'-1px 0',right:'35px'}} labelStyle={{paddingLeft:0}} onChange={this.handleChangeinDropDown.bind(null,selectedmenuonclick[i].name.products[element],selectedmenuonclick[i].name.products[element].id)}>

 { selectedmenuonclick[i].name.products[element].childProducts.map((childProduct,index)=>{    
          return ( <MenuItem key={index} value={childProduct.id}  primaryText={`${childProduct.productQuantity} ${childProduct.productUnit}`} />)

      })
    }
     </DropDownMenu>
   
  
         </div>
      


      <div  className=" col-lg-9 col-md-9 col-xs-9 productNameHeader">
      <div className="priceSection">
         <span className="amountafterdiscount">Rs {selectedmenuonclick[i].name.products[element].discountedPrice}</span>
         <span className="originalamount">{selectedmenuonclick[i].name.products[element].productPrice}</span>
         <span className="discountpercent">{`${selectedmenuonclick[i].name.products[element].discountPerCent}%`}</span>
         </div>
         </div>
         <RaisedButton label="BUY" buttonStyle={{background:"#de3900"}}   style={{float:'left',minWidth:85}}/>
         {this.props.lastadded.indexOf(selectedmenuonclick[i].name.products[element].id)!=-1 ?
              <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={true}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

:      <RaisedButton label="Add" id={selectedmenuonclick[i].name.products[element].id} disabled={selectedmenuonclick[i].name.products[element].id===this.state.disabled ? true:false}  secondary={true} onClick={this.handleAddProductRequest.bind(null,selectedmenuonclick[i].name.products[element].id)}   style={{float:'right',minWidth:85}}/> 

       }
        
     
</div>         );
}
break;}
 
        

}
  return(
   <div className="col-lg-9 col-md-9 col-xs-12 col-sm-12" style={{borderLeft:'10px solid transparent'}}>
 <div className="row shopcategoriesSection">
      <div className="selectedcategorytitle">{selectedcategoryName}</div>
      </div>
    <div id="myCarousel" className="carousel slide row" data-ride="carousel">
        {/*<!-- Wrapper for slides -->*/}   
        <div className="carousel-inner">
            <div className="item active">
                <img src="http://placehold.it/1200x400/16a085/ffffff&text=About Us"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/e67e22/ffffff&text=Projects"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
          {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/2980b9/ffffff&text=Portfolio"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
            {/*<!-- End Item -->*/} 
            <div className="item">
                <img src="http://placehold.it/1200x400/8e44ad/ffffff&text=Services"/>
                <div className="carousel-caption">
                    <h3>
                        Headline</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod
                        tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem
                        ipsum dolor sit amet, consetetur sadipscing elitr.</p>
                </div>
            </div>
      {/* <!-- End Item --> */} 
        </div>
        {/* <!-- End Carousel Inner --> */}
        <ul className="nav nav-pills nav-justified">
            <li data-target="#myCarousel" data-slide-to="0" className="active"><a href="#">About<small>Lorem
                ipsum dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="1"><a href="#">Projects<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="2"><a href="#">Portfolio<small>Lorem ipsum
                dolor sit</small></a></li>
            <li data-target="#myCarousel" data-slide-to="3"><a href="#">Services<small>Lorem ipsum
                dolor sit</small></a></li>
        </ul>
    </div>
  {/*<!-- End Carousel --> */} 




    
    {isListFetching && <div className="row features-loader"><div className="alingCenter"><CircularProgress size={70} thickness={6} /><div className="selectedcategorytitle">Fetching Our Latest Offers</div></div></div>}
    
    {!isListFetching  && this.state.updatePage===true && <div className="row features-grid">
   { item} 

</div>
    }

{ this.state.handleSnackbar===true && <Snackbar open={this.state.handleSnackbar} message={`wopiee Addedd Successfuly ${lastadded[lastadded.length-1].name}`} autoHideDuration={4000} />}

{this.state.largeView===true &&      <Dialog
          title="Large View "
      actions={<FlatButton
      label="Ok"
      primary={true}
      onTouchTap={this.handleClose}
      keyboardFocused={true}/>}
          modal={false}
          open={this.state.largeView}
          onRequestClose={this.handleClose}
         
        >
    <div className="row" style={{paddingTop:10,borderTop:'1px solid rgb(224, 224, 224)'}}>
<div className="col-xs-6 col-md-6 col-lg-6 col-sm-6" style={{height:300}}><img src="C:/Users/753554/Downloads/checkonly.png" style={{width:"100%"}}/></div>
    <div className="col-xs-6 col-md-6 col-lg-6 col-sm-6 largeViewDialog" style={{height:300}}>
    <div className="largeviewTitle">Details</div>
    <div>{this.state.dataForlargeView.description}</div>
    </div>
    </div>
        </Dialog>}
{/* End of MainContent */}

</div> 

  )
} 
  
}

const mapStateToProps=(state,ownProps)=>{
  const {listofAddProduct,fetchmenuReducer,fetchsubitemReducer}=state;
const {selectedcategoryName,selectedmenuonclick}=fetchmenuReducer;
const {lastadded}=state.listofAddProduct;
console.log('vfvf',lastadded);
const {isListFetching,Listitems}=fetchsubitemReducer[fetchsubitemReducer.subcategoryItem]||{isListFetching:false,Listitems:[]};
return {lastadded,selectedmenuonclick,isListFetching,Listitems,selectedcategoryName};

}


export default connect(mapStateToProps)(ProductList);

