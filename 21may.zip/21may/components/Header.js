import React from 'react';
import AppBar from 'material-ui/AppBar';
import IconMenu  from 'material-ui/IconMenu';
import MenuItem from 'material-ui/MenuItem';
import IconButton from 'material-ui/IconButton/IconButton';
import AutoComplete from 'material-ui/AutoComplete';
import TextField from 'material-ui/TextField';
import MapsPlace  from 'material-ui/svg-icons/maps/place';
import {List, ListItem} from 'material-ui/List';
import NavigationMenu from 'material-ui/svg-icons/navigation/menu';
import SocialPersonOutline from 'material-ui/svg-icons/social/person-outline';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import ActionInfo from 'material-ui/svg-icons/action/info';
import Badge from 'material-ui/Badge';
import Drawer from 'material-ui/Drawer';
import Subheader from 'material-ui/Subheader';
import CircularProgress from 'material-ui/CircularProgress';
import {connect} from 'react-redux';
import {Link} from 'react-router';
import {select_submenu,selected_menu_click,fetchsubitem,fetchmenus,recieve_product_status,searchrequest,searchlocally} from '../actions/actions';

const styles = {
  radioButton: {
    marginTop: 16,
  }
};
const loaderforSearch={position:'absolute',
    top: -23,
    right: 135}
const subHeaderStyle={color:"#00B9F5",
    fontWeight: 600,
    fontSize: 16};
class Header extends React.Component{
	constructor(props)
	{
		super(props);
		
		this.state={open:false,openDrawer:false,searchrepository:null,initallocalrepository:false};
	this.handleOpen=this.handleOpen.bind(this);
		this.handleClose=this.handleClose.bind(this);
		this.handleDrawerClose=this.handleDrawerClose.bind(this);
		this.handleDrawerMenu=this.handleDrawerMenu.bind(this);
		this.handleClick=this.handleClick.bind(this);
		this.handleRequestChange=this.handleRequestChange.bind(this);
		this.searchSomething=this.searchSomething.bind(this);
		
	}
	componentDidMount(){const{dispatch}=this.props;
	dispatch(fetchmenus());
}

searchSomething(value){
	console.log("dataSource"+this.props.dataSourceLocally);
	console.log("dsd"+this.props.dataSourceLocally.toString().indexOf(value));
	if(value.length>=1 &&  this.props.dataSourceLocally.toString().indexOf(value) == -1 && this.state.initallocalrepository==true){
		console.log("Request Start from Here");
this.props.dispatch(searchrequest(value));
this.setState({searchrepository:1});
}
else
{
console.log("I have Values");
this.props.dispatch(searchlocally(value));
this.setState({searchrepository:0,initallocalrepository:true});
}
}

	  handleOpen(){
    this.setState({open: true});
  }
  handleClose(){
    this.setState({open: false});
  }
  handleDrawerClose(){
	this.setState({openDrawer:false});	
}
handleDrawerMenu(){
	
	this.setState({openDrawer:true});	
}
handleClick(item,layout,event)
	{ $('html, body').animate({
        scrollTop: $(".features-grid").offset().top-60
    }, 2000);
	this.setState({openDrawer:false});
 this.props.dispatch(selected_menu_click(item));
	}
	handleRequestChange(open)
	{ this.setState({openDrawer: open});
		
	}
	render(){
		console.log("State of repository "+this.state.searchrepository);
		const {items,lastadded,isFetching,isSearchFetching,dataSource,dataSourceLocally}=this.props;
		console.log("Inside Header "+dataSource);
		 const actions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onTouchTap={this.handleClose}
      />,
     <FlatButton
        label="Submit"
        primary={true}
     
 containerElement={<Link to="/checkout"/>}
 
        onTouchTap={this.handleClose}
	    style={{overflow:'none'}} />,
    ];

let dt=[];
	 dt=dataSource;
		return (
		<AppBar 
		title="Title" iconStyleRight={{width:"80%",marginTop:0}}  titleStyle={{color:"rgb(0, 188, 212)"}} style={{backgroundColor:"#fff",position:"fixed",boxShadow: "rgba(0, 0, 0, 0.298039) 0px 19px 60px, rgba(0, 0, 0, 0.219608) 0px 15px 20px"}}
		 iconElementLeft={<IconButton  onTouchTap={this.handleDrawerMenu} tooltip="Menu" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><NavigationMenu/>
		
		 		 </IconButton>}
		iconElementRight={
		<div>
		<div className="visible-sm-inline-block visible-md-inline-block visible-lg-inline-block" style={{width:"88%"}}>

    <AutoComplete className="searchbox"
          floatingLabelText='Search for Products e.g Panner'
          dataSource={(this.state.searchrepository==1) ? dt:dataSourceLocally}
          onUpdateInput={this.searchSomething}
     fullWidth={true}
     hintText="All OK"
      openOnFocus={true}
     maxSearchResults={10}
         filter={AutoComplete.fuzzyFilter} />
     {isSearchFetching==true && <div style={loaderforSearch}><div className="alingCenter"><CircularProgress size={30} thickness={4} /></div></div>}
	</div>
		<div className="visible-xs-inline-block" style={{width:"88%"}}>
  <AutoComplete className="searchbox"
          floatingLabelText='Search for Products e.g Panner'
          dataSource={(this.state.searchrepository==1)? dt:dataSourceLocally}
        onUpdateInput={this.searchSomething}
     fullWidth={true}
       hintText="All OK"
     maxSearchResults={10}
      openOnFocus={true}
           filter={AutoComplete.fuzzyFilter} />
            {isSearchFetching==true && <div style={loaderforSearch}><div className="alingCenter"><CircularProgress size={30} thickness={4} /></div></div>}
	</div>
	<IconMenu style={{position:"fixed",right: 0,top:10}}
iconButtonElement={<IconButton tooltip="Login" tooltipPosition="bottom-center" ><SocialPersonOutline /></IconButton>}
	anchorOrigin={{horizontal:'left',vertical:'top'}} targetOrigin={{horizontal:'left',vertical:'top'}} maxHeight={272} >
		<MenuItem primaryText="Refresh" />
      <MenuItem primaryText="Send feedback" />
      <MenuItem primaryText="Settings" />
      <MenuItem primaryText="Help" />
      <MenuItem primaryText="Sign out" />
		</IconMenu>
		 <IconMenu style={{position:"fixed",right:37,top:10}} 
     iconButtonElement={<IconButton tooltip="Change Location" tooltipPosition="bottom-center" iconStyle={{fill:"rgb(0, 188, 212)"}}><MapsPlace/></IconButton>} 
      anchorOrigin={{horizontal: 'left', vertical: 'top'}}
      targetOrigin={{horizontal: 'left', vertical: 'top'}}
    >
      <MenuItem primaryText="Lucknow" />
      <MenuItem primaryText="Agra" />
    </IconMenu>
		<Badge
		badgeContent={lastadded.length===0 ? 0:lastadded.length} primary={true} style={{position:"fixed",right:87,cursor:'pointer',width:22,height:22}} badgeStyle={{top:7,right:-10,width:20,height:20}}> 
		<NotificationsIcon onTouchTap={this.handleOpen}/>
		</Badge>
		<Dialog
          title="Scrollable Dialog"
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
          autoScrollBodyContent={true}
        >
          <List>
		  {lastadded.length!=0 && lastadded.map((addedItem,i)=>{
			 return( <ListItem
          key={i}
          primaryText={addedItem.id}
          rightIcon={<ActionInfo />}
		  />) 
		  })
		  }
      </List>
        </Dialog>
		 <Drawer 
		docked={false} 
		width={250}
		open={this.state.openDrawer}
		 onRequestChange={this.handleRequestChange}
		 >

		 <Subheader style={subHeaderStyle}>Shop by Category</Subheader>
	 {isFetching && items.length==0 && <div className="alingCenter"><CircularProgress size={60} thickness={7} /></div>}	
			{!isFetching && items.map((item,i)=>
		 {return(<Link to={`/paytm/${item}`} key={i} ><MenuItem  className="listitem" innerDivStyle={{fontSize:'1.4rem',textTransform:'uppercase',padding:10,lineHeight:0,marginTop:10}}
		 
		 primaryText={item} key={i} ref={item} onTouchTap={this.handleClick.bind(null,item,1)}
		 />	 </Link>
)
		 }
		 )}
		
		</Drawer>
		</div>
		}/>
		)
	}
}



const mapStateToProps=(state,ownProps)=>{
	const {listofAddProduct,fetchmenuReducer,searchDataSource}=state;
const {isFetching,items}=fetchmenuReducer;
const{isSearchFetching,dataSource,dataSourceLocally}=searchDataSource;

const {lastadded}=listofAddProduct;
return {lastadded,isFetching,items,isSearchFetching,dataSource,dataSourceLocally};

}

export default connect(mapStateToProps)(Header);